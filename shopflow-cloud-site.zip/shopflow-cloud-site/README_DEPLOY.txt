AWS EC2 ga deploy qilish qisqa ketma-ketligi

1) EC2 Ubuntu server yarating.
2) Security Group ichida 22, 80 va 443 portlarni oching.
3) SSH orqali serverga kiring.
4) Nginx o'rnating:
   sudo apt update
   sudo apt install nginx -y
5) Ushbu sayt fayllarini serverga yuklang.
6) Fayllarni Nginx papkasiga ko'chiring:
   sudo rm -rf /var/www/html/*
   sudo cp -r * /var/www/html/
7) Nginxni qayta ishga tushiring:
   sudo systemctl restart nginx
8) Brauzerda EC2 Public IPv4 address orqali saytni tekshiring.

HTTPS kerak bo'lsa:
- Bepul domen/subdomain: DuckDNS
- SSL certificate: Certbot Let's Encrypt
